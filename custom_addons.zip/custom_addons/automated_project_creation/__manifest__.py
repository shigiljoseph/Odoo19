
{
    'name':'Automated Project Creation',
    'version': '1.3',
    'application':True,
    'data':[
        'views/sale_order_views.xml',
    ],
    'depends':['base','sale','purchase'],
    'sequence':2,
    'auto_install': True,
    'license': 'LGPL-3'
}