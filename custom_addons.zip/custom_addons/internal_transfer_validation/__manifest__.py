# -*- coding: utf-8 -*-

{
    'name' : 'Internal Transfer Validation',
    'version': '19.0.1.0.0',
    'sequence':2,
    'depends':['base','purchase','sale'],
    "application": True,
    'license': 'LGPL-3',
    'author': 'Odoo S.A.',
    'auto_install': False,
    'summary':'Stock internal transfers  second user validation'
}

