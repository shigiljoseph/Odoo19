# -*- coding: utf-8 -*-

from . import department
from . import student_class
from . import subjects
from . import academic_year
from . import student_registration
from . import school_club
from . import school_events
from . import sale_order
from . import res_partner
from . import student_leave
from . import student_exam

