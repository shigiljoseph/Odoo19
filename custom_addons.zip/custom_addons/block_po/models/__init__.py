# -*- coding: utf-8 -*-

from. import res_partner
from . import purchase_order
from . import sale_order
from . import sale_order_line