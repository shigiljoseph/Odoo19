{
    'name': 'Real Estate',
    'data' : [
        'security/ir.model.access.csv',
        'views/estate_property_views.xml',
        'views/Property_Types.xml',
        'views/property_tag.xml',
        'views/estate_offer.xml',
        'views/estate_menu.xml'


    ],
    "application": True
    }