# -*- coding: utf-8 -*-

{
    'name' : 'Vendor Products',
    'version': '19.0.1.0.0',
    'sequence':2,
    "data":[
        'views/purchase_order_view.xml',
    ],
    'depends':['base','purchase'],
    "application": True,
    'license': 'LGPL-3',
    'author': 'Odoo S.A.',
    'auto_install': False,
    'summary':'To show the products of the corresponding vendor.'
}

